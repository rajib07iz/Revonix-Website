window.onload = function() {
    alert("Welcome to Revonix - Expert Mobile Repair!");
};
